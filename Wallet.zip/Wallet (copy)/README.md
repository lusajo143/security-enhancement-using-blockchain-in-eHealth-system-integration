# Blockchain Wallet

This is a chrome extension to be used as sec doc wallet. It stores user identity in secured manner as it encripts before
storing in chrome storage And decripts when connecting to sec application.